package service;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;

import br.unifor.poo.model.Departamento;
import br.unifor.poo.model.Funcionario;
 
@ManagedBean(name="dtTableStateView")
@SessionScoped
public class TableStateView implements Serializable {
	private static final long serialVersionUID = 1L;
	
    private List<Funcionario> filteredFuncionarios = null;
     
    private Funcionario selectedFuncionario = null;
     
    @ManagedProperty("#{funcionarioService}")
    private FuncionarioService service;
 
    @PostConstruct
    public void init() {
    	//update(); //funcionarios = service.getFuncionarios();
    }
    
    public List<Departamento> getDepartamentos() {
        return service.getDepartamentos();
    }
     
    public List<Funcionario> getFuncionarios() {
        return service.getFuncionarios();//funcionarios;
    }
 
    public List<Funcionario> getFilteredFuncionarios() {
        return filteredFuncionarios;
    }
 
    public Funcionario getSelectedFuncionario() {
        return selectedFuncionario;
    }
 
    public void setSelectedFuncionario(Funcionario selectedFuncionario) {
        this.selectedFuncionario = selectedFuncionario;
    }
 
    public void setFilteredFuncionarios(List<Funcionario> filteredFuncionarios) {
        this.filteredFuncionarios = filteredFuncionarios;
    }
 
    public void setService(FuncionarioService service) {
        this.service = service;
    }
    public void update() {
        //funcionarios = service.getFuncionarios();
    	System.out.println("****************************************************************");
    	if(filteredFuncionarios!=null)
	    	filteredFuncionarios.forEach(f->{
	    		System.out.println(f.getNome());
	    	});
    	System.out.println("****************************************************************");
    	if(selectedFuncionario!=null) { 
    		System.out.println("################################# "+selectedFuncionario.getNome());
    		selectedFuncionario.setNome(selectedFuncionario.getNome()+(++count));
    		service.setFuncionario(selectedFuncionario);
    	}
    }
    private int count = 0;
}