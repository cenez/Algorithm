package service;

import java.util.List;

import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;

import br.unifor.poo.model.Departamento;
import br.unifor.poo.model.Funcionario;
import br.unifor.poo.model.dao.DAO;
import br.unifor.poo.util.ConnectionFactory;
 
@ManagedBean(name = "funcionarioService")
@ApplicationScoped
public class FuncionarioService {
	
    private static DAO<Funcionario, Long> dao = new DAO<Funcionario, Long>(ConnectionFactory.currentManager(), Funcionario.class);
    private static DAO<Departamento, Long> daoDp = new DAO<Departamento, Long>(ConnectionFactory.currentManager(), Departamento.class);
     
    public List<Funcionario> getFuncionarios() {
    	return dao.list();
    }
    
    public List<Departamento> getDepartamentos() {
        return daoDp.list();
    }
    public void setFuncionario(Funcionario f) {
    	dao.save(f);
    }
     
//    public List<String> getBrands() {
//        return Arrays.asList(brands);
//    }
}
