package tx;

public class GerenciadorDeTransacao{}
/*
@Interceptor
public class GerenciadorDeTransacao implements Serializable{
    private static final long serialVersionUID = 1L;

    @Inject
    EntityManager entityManager;

    @AroundInvoke
    public Object executa(InvocationContext contexto) throws Exception{

        entityManager.getTransaction().begin();

        Object result = contexto.proceed();

        entityManager.getTransaction().commit();

        return result;
    }
}
*/
